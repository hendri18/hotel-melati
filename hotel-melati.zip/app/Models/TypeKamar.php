<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TypeKamar extends Model
{
    protected $table = 'type_kamar';
    protected $primaryKey = 'id_type_kamar';
    public $timestamps = false; 
}
