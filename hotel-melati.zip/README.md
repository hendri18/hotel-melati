## Hotel Melati

Step to install:
- `composer install`
- create `.env` file
- setup `.env` file
- `php artisan key:generate`
- `php artisan migrate`
- `php artisan db:seed --class=AllTableSeeder`
- `npm install`
- `npm run dev` or `npm run watch`
- `php artisan serve`

Production
- `npm run prod`